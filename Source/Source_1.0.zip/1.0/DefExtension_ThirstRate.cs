﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Verse;

namespace MizuMod
{
    public class DefExtension_ThirstRate : DefModExtension
    {
        public List<float> thirstRateFactors;
        public List<float> thirstRateFactorOffsets;
    }
}
