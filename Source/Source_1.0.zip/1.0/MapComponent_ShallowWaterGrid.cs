﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using UnityEngine;
using Verse;

namespace MizuMod
{
    public class MapComponent_ShallowWaterGrid : MapComponent_WaterGrid
    {
        public MapComponent_ShallowWaterGrid(Map map) : base(map)
        {

        }
    }
}
