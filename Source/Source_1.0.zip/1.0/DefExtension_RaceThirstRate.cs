﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Verse;

namespace MizuMod
{
    public class DefExtension_RaceThirstRate : DefModExtension
    {
        public float baseThirstRate = 1f;
    }
}
