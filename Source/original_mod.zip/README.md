# No Water, No Life.
MOD for RimWorld B19

## License
This mod includes a compiled version of the Harmony library (0Harmony.dll) made by Andreas Pardeike (MIT license).
https://github.com/pardeike/Harmony

other files are released under the Unlicense.

